<?php

return [
    'host'      => 'localhost',
    'puerto'    => '3306',
    'nombre_bd' => 'db_banco_adso',
    'usuario'   => 'root',
    'clave'     => '3027',
    'charset'   => 'utf8mb4',
];