<?php

declare(strict_types=1);

namespace App\Nucleo;

/**
 * Base común para los controladores que requieren sesión activa.
 *
 * Centraliza en un solo lugar la verificación "¿hay sesión activa?" para
 * que ninguna acción nueva pueda olvidarla por descuido, y ofrece
 * ayudantes delgados para redirigir y renderizar vistas.
 */
abstract class ControladorBase
{
    protected function requerirSesion(): void
    {
        if (!isset($_SESSION['cuenta_id'])) {
            $this->redirigir('login/mostrar');
        }
    }

    protected function idCuentaSesion(): int
    {
        return (int) $_SESSION['cuenta_id'];
    }

    protected function renderizar(string $vista, array $datos = []): void
    {
        Vista::render($vista, $datos);
    }

    protected function redirigir(string $ruta): never
    {
        header('Location: index.php?ruta=' . $ruta);
        exit;
    }

    /**
     * Guarda un mensaje de una sola lectura en sesión, para mostrarlo
     * después de un redirect (patrón POST/Redirect/GET).
     */
    protected function guardarFlash(string $clave, string $mensaje): void
    {
        $_SESSION[$clave] = $mensaje;
    }

    protected function leerFlash(string $clave): ?string
    {
        $mensaje = $_SESSION[$clave] ?? null;
        unset($_SESSION[$clave]);

        return $mensaje;
    }
}
