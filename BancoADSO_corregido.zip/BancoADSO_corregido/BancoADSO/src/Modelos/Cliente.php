<?php

declare(strict_types=1);

namespace App\Modelos;

/**
 * Identidad de la persona. No sabe nada de SQL ni de HTML.
 */
final class Cliente
{
    public function __construct(
        public readonly int $id,
        public readonly string $nombre,
    ) {
    }
}
