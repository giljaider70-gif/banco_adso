<?php

declare(strict_types=1);

namespace App\Modelos;

/**
 * Producto bancario. El saldo se maneja como string para preservar la
 * precisión del DECIMAL(12,2) de base de datos (nunca float).
 */
final class Cuenta
{
    public function __construct(
        public readonly int $id,
        public readonly string $numeroCuenta,
        public readonly string $saldo,
        public readonly int $clienteId,
    ) {
    }
}
