<?php

declare(strict_types=1);

namespace App\Modelos;

/**
 * Mecanismo de acceso a la aplicación, separado de Cliente y Cuenta.
 */
final class Usuario
{
    public function __construct(
        public readonly int $id,
        public readonly int $cuentaId,
        public readonly string $claveHash,
    ) {
    }
}
