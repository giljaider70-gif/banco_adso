<?php

declare(strict_types=1);

namespace App\Controladores;

use App\Nucleo\Conexion;
use App\Nucleo\ControladorBase;
use App\Repositorios\RepositorioCuenta;

final class PanelControlador extends ControladorBase
{
    /**
     * RF3: el saldo se consulta a base de datos en cada visita al
     * panel, nunca se reutiliza un valor guardado desde el login.
     */
    public function indexAccion(): void
    {
        $this->requerirSesion();

        $repositorioCuenta = new RepositorioCuenta(Conexion::obtener());
        $idCuenta = $this->idCuentaSesion();

        $cuenta = $repositorioCuenta->buscarPorId($idCuenta);
        $saldo = $repositorioCuenta->obtenerSaldo($idCuenta);

        $this->renderizar('panel', [
            'tituloPagina' => 'Panel de la cuenta',
            'cuenta' => $cuenta,
            'saldo' => $saldo,
            'mensajeExito' => $this->leerFlash('flash_exito'),
        ]);
    }
}
