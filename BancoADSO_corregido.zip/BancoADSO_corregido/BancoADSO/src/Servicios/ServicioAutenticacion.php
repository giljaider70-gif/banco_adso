<?php

declare(strict_types=1);

namespace App\Servicios;

use App\Excepciones\CredencialesInvalidasException;
use App\Modelos\Cuenta;
use App\Repositorios\RepositorioCuenta;
use App\Repositorios\RepositorioUsuario;

/**
 * Regla de negocio de acceso: valida número de cuenta + contraseña
 * (login), y reconfirmación de contraseña (retiro/transferencia).
 * No sabe nada de HTTP ni de HTML.
 */
final class ServicioAutenticacion
{
    public function __construct(
        private readonly RepositorioCuenta $repositorioCuenta,
        private readonly RepositorioUsuario $repositorioUsuario,
    ) {
    }

    /**
     * RF1: el mensaje de error debe ser idéntico tanto si el número de
     * cuenta no existe como si existe pero la contraseña no coincide —
     * mostrar mensajes distintos en cada caso es una fuga de información.
     */
    public function autenticar(string $numeroCuenta, string $contrasena): Cuenta
    {
        $mensajeGenerico = 'Número de cuenta o contraseña incorrectos';

        $cuenta = $this->repositorioCuenta->buscarPorNumero($numeroCuenta);
        if ($cuenta === null) {
            throw new CredencialesInvalidasException($mensajeGenerico);
        }

        $usuario = $this->repositorioUsuario->buscarPorCuentaId($cuenta->id);
        if ($usuario === null) {
            throw new CredencialesInvalidasException($mensajeGenerico);
        }

        if (!password_verify($contrasena, $usuario->claveHash)) {
            throw new CredencialesInvalidasException($mensajeGenerico);
        }

        return $cuenta;
    }

    /**
     * Misma regla de negocio del login ("¿esta contraseña es correcta
     * para esta cuenta?"), aplicada en retiro y transferencia (RN4).
     */
    public function reconfirmarContrasena(int $cuentaId, string $contrasena): void
    {
        $usuario = $this->repositorioUsuario->buscarPorCuentaId($cuentaId);

        if ($usuario === null || !password_verify($contrasena, $usuario->claveHash)) {
            throw new CredencialesInvalidasException('La contraseña ingresada no es correcta');
        }
    }
}