<?php

declare(strict_types=1);

namespace App\Excepciones;

use RuntimeException;

/**
 * El número de cuenta, la contraseña, o la reconfirmación de contraseña
 * en retiro/transferencia, no corresponden ("¿esta contraseña es
 * correcta para esta cuenta?" aplicada en cualquier punto del flujo).
 */
final class CredencialesInvalidasException extends RuntimeException
{
}
