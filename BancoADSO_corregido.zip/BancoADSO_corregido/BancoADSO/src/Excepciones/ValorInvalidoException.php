<?php

declare(strict_types=1);

namespace App\Excepciones;

use InvalidArgumentException;

/**
 * El valor ingresado para un retiro o una transferencia no es numérico
 * o no es mayor que 0.
 */
final class ValorInvalidoException extends InvalidArgumentException
{
}
