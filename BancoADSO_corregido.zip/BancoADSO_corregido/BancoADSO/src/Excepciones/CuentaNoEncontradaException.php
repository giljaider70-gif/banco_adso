<?php

declare(strict_types=1);

namespace App\Excepciones;

use RuntimeException;

/**
 * La cuenta destino de una transferencia no existe en la tabla cuentas.
 */
final class CuentaNoEncontradaException extends RuntimeException
{
}
