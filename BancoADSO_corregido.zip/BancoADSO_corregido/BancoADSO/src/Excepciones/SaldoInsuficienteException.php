<?php

declare(strict_types=1);

namespace App\Excepciones;

use RuntimeException;

/**
 * El saldo disponible en la cuenta origen no alcanza para cubrir un
 * retiro o una transferencia.
 */
final class SaldoInsuficienteException extends RuntimeException
{
}
