<?php

declare(strict_types=1);

/**
 * Escapa un valor para salida segura en HTML. Toda variable que venga
 * de datos del usuario o de base de datos se imprime a través de esta
 * función en las vistas.
 */
function e(mixed $valor): string
{
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}

/**
 * Formatea un valor monetario (string/DECIMAL) para mostrarlo en las
 * vistas, con separador de miles y coma decimal. Es puramente de
 * presentación: no se usa para ningún cálculo.
 */
function formatearDinero(string $valor): string
{
    return number_format((float) $valor, 2, ',', '.');
}
