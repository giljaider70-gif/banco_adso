<?php
// ARCHIVO TEMPORAL DE DIAGNÓSTICO — bórralo cuando termines.
declare(strict_types=1);
ini_set('display_errors', '1');
error_reporting(E_ALL);

require_once __DIR__ . '/../vendor/autoload.php';

$rutaSesiones = __DIR__ . '/../storage/sessions';
if (!is_dir($rutaSesiones)) {
    mkdir($rutaSesiones, 0777, true);
}
session_save_path($rutaSesiones);
session_start();

$_SESSION['visitas'] = ($_SESSION['visitas'] ?? 0) + 1;

function ok(bool $v): string { return $v ? '✅ OK' : '❌ FALLA'; }

echo '<body style="font-family:sans-serif;max-width:800px;margin:2rem auto;line-height:1.6">';
echo '<h2>Diagnóstico Banco ADSO</h2>';

// 1. Sesión
echo '<h3>1. Sesión</h3>';
echo 'Versión de PHP: ' . PHP_VERSION . '<br>';
echo 'Carpeta de sesiones: ' . htmlspecialchars(session_save_path()) . ' — escribible: ' . ok(is_writable(session_save_path())) . '<br>';
echo 'Visitas en esta sesión: <b>' . $_SESSION['visitas'] . '</b> ';
echo '(recarga la página: si SIEMPRE dice 1, el navegador no guarda la cookie de sesión)<br>';
echo 'Cookie PHPSESSID recibida: ' . ok(isset($_COOKIE[session_name()])) . '<br>';

// 2. Argon2
echo '<h3>2. Soporte Argon2id</h3>';
echo 'PASSWORD_ARGON2ID disponible: ' . ok(defined('PASSWORD_ARGON2ID')) . '<br>';

// 3. Base de datos
echo '<h3>3. Base de datos</h3>';
try {
    $pdo = App\Nucleo\Conexion::obtenerInstancia();
    echo 'Conexión: ✅ OK<br>';
    echo 'Base en uso: <b>' . htmlspecialchars((string) $pdo->query('SELECT DATABASE()')->fetchColumn()) . '</b><br>';
    echo 'Puerto del servidor MySQL: <b>' . htmlspecialchars((string) $pdo->query('SELECT @@port')->fetchColumn()) . '</b><br>';

    $cuentas = $pdo->query('SELECT id, numero_cuenta FROM cuentas')->fetchAll();
    echo 'Cuentas encontradas: <b>' . count($cuentas) . '</b><br>';
    foreach ($cuentas as $c) {
        echo '&nbsp;&nbsp;id=' . $c['id'] . ' número=[' . htmlspecialchars($c['numero_cuenta']) . ']<br>';
    }

    $usuarios = $pdo->query('SELECT cuenta_id, LEFT(clave_hash, 30) AS inicio, LENGTH(clave_hash) AS largo FROM usuarios')->fetchAll();
    echo 'Usuarios encontrados: <b>' . count($usuarios) . '</b><br>';
    foreach ($usuarios as $u) {
        echo '&nbsp;&nbsp;cuenta_id=' . $u['cuenta_id'] . ' hash empieza: ' . htmlspecialchars($u['inicio']) . '… largo=' . $u['largo'] . '<br>';
    }
} catch (Throwable $e) {
    echo '❌ Error: ' . htmlspecialchars($e->getMessage()) . '<br>';
}

// 4. Probar contraseña
echo '<h3>4. Probar contraseña</h3>';
echo '<form method="post"><input name="n" placeholder="número de cuenta"> <input name="c" type="password" placeholder="contraseña"> <button>Probar</button></form>';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($pdo)) {
    $n = trim((string) ($_POST['n'] ?? ''));
    $c = (string) ($_POST['c'] ?? '');
    $st = $pdo->prepare('SELECT u.clave_hash FROM cuentas ct JOIN usuarios u ON u.cuenta_id = ct.id WHERE ct.numero_cuenta = :n');
    $st->execute(['n' => $n]);
    $hash = $st->fetchColumn();
    if ($hash === false) {
        echo '❌ No se encontró cuenta + usuario para [' . htmlspecialchars($n) . ']';
    } else {
        echo 'Cuenta y usuario encontrados ✅<br>';
        echo 'password_verify: ' . ok(password_verify($c, (string) $hash));
    }
}
echo '</body>';
