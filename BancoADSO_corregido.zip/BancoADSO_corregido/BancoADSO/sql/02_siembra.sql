
USE db_banco_adso;

INSERT INTO clientes(nombre) VALUES
('Jaider Gil'),
('María Rodríguez'),
('Ana Gómez'),
('Luis Torres'),
('Sofia Martínez');

INSERT INTO cuentas (numero_cuenta, saldo, clientes_id) VALUES
('1001', 500000.00, 1),
('1002', 750000.00, 2),
('1003', 1200000.00, 3),
('1004', 300000.00, 4),
('1005', 950000.00, 5);


INSERT INTO usuarios(cuenta_id, clave_hash) VALUES
(1, '$argon2id$v=19$m=19456,t=2,p=1$3SMiOMhiGX2jMonK2rb+gg$GVp8sXhytHdnYrXIBb642ggpHzzTyhX6Rn0Me/IV1TQ'),
(2, '$argon2id$v=19$m=19456,t=2,p=1$3SMiOMhiGX2jMonK2rb+gg$qIKjgQlXysB7qwackI3yc8UHEgSlH1cKHrSyWfKxgaE'),
(3, '$argon2id$v=19$m=19456,t=2,p=1$noHtGiW6mE595/iF0y+Vsw$nQHna82sv+GQRhsBjqarc+0UD65ZJDEyLMwnRxTe0uw'),
(4, '$argon2id$v=19$m=19456,t=2,p=1$noHtGiW6mE595/iF0y+Vsw$E4mls5K2xCfxza+DFigbgjI3+EEsutqhEfFM3C2SaIE'),
(5, '$argon2id$v=19$m=19456,t=2,p=1$noHtGiW6mE595/iF0y+Vsw$JY2RQqWHC1NylTT1PHirj9A9AgLqVuGXajEbJidppes');
